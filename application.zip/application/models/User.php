<?php

class User extends CI_Model{

    public $table_name = 'user';

    public function get() {
        $results = $this->db->get($table_name);
        return $results;
    }

    public function validateUser($email, $password){
        $results = $this->db->get_where($table_name, array(
            'email' => $email,
            'password' => $password
        ));
    }

    public function update($update, $userCondition){
        /*
            $update = array ( 
                'first_name' => 'Shridatt',
                'last_name' => 'Z',
            )

            $userCondition = array ( 
                'email' => 'shridattz@gmail.com'
            )

        */
        
        $result = $this->db->insert($table_name, $update, $userCondition);
    }

    public function create($user){
        /*
            $user = array ( 
                'first_name' => 'Shridatt',
                'last_name' => 'Z',
                'email' => 'shridattz@gmail.com',
                'password' => 'password123'
            )
        */
        $result = $this->db->insert($table_name, $user);

    }

    public function delete($userCondition){
        /*
            $userCondition = array ( 
                'email' => 'shridattz@gmail.com'
            )
        */
        $result = $this->db->delete($table_name, $userCondition);
    }



}